# Prometheus Add-on

This add-on is an experimental configuration of k8s monitoring using Prometheus used for e2e tests.

For production use check out more mature setups like [Prometheus Operator](https://github.com/coreos/prometheus-operator) and [kube-prometheus](https://github.com/coreos/prometheus-operator/tree/master/contrib/kube-prometheus).